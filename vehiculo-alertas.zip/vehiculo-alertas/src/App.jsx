import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableHead, TableRow, TableCell, TableBody } from "@/components/ui/table";
import { format, differenceInDays } from "date-fns";

export default function VehiculosApp() {
  const [datos, setDatos] = useState([]);

  useEffect(() => {
    const datosEjemplo = [
      {
        placa: "ABC123",
        vehiculo: "Jetta 2018",
        seguro: "2025-05-15",
        verificacion: "2025-07-10",
      },
      {
        placa: "XYZ789",
        vehiculo: "Sentra 2020",
        seguro: "2025-04-25",
        verificacion: "2025-05-05",
      },
    ];
    setDatos(datosEjemplo);
  }, []);

  const getEstado = (fecha) => {
    const dias = differenceInDays(new Date(fecha), new Date());
    if (dias < 0) return "Vencido ❌";
    if (dias <= 15) return `Por vencer (${dias} días) ⚠️`;
    return `Vigente (${dias} días) ✅`;
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Control de Seguros y Verificaciones</h1>
      <Card>
        <CardContent>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Placa</TableCell>
                <TableCell>Vehículo</TableCell>
                <TableCell>Seguro vence</TableCell>
                <TableCell>Estado seguro</TableCell>
                <TableCell>Verificación próxima</TableCell>
                <TableCell>Estado verificación</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {datos.map((item, index) => (
                <TableRow key={index}>
                  <TableCell>{item.placa}</TableCell>
                  <TableCell>{item.vehiculo}</TableCell>
                  <TableCell>{format(new Date(item.seguro), "dd/MM/yyyy")}</TableCell>
                  <TableCell>{getEstado(item.seguro)}</TableCell>
                  <TableCell>{format(new Date(item.verificacion), "dd/MM/yyyy")}</TableCell>
                  <TableCell>{getEstado(item.verificacion)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
